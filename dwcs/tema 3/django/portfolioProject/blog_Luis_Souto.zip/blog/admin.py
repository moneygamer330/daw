from django.contrib import admin
from .models import Blog

# Register your models here.

admin.site.register(Blog) #registrar clases en base de datos
